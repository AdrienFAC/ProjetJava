package projet;
public class Couleur
{
	int r;
	int g;
	int b;
	int a;
	
	public Couleur(int r, int g, int b, int a)
	{
		this.r = r;
		this.g= g;
		this.b = b;
		this.a = a;
	}
}
