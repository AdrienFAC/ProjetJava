package projet;
public class Taille
{
	int hauteur;
	int largeur;
	
	public Taille(int largeur, int hauteur)
	{
		this.hauteur = hauteur;
		this.largeur = largeur;
	}
}

