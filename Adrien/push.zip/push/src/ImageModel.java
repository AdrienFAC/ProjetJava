import java.awt.Dimension;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.imageio.ImageIO;

public class ImageModel
{
	BufferedImage image;
	Dimension taille;
	Couleur couleur;
	String titre;
	List<String> lst_tags;
	int note;
	long temps;
	
	static String parseTitre(String path)
	{
		File fichier = new File(path);
		
		String result = fichier.getAbsolutePath().substring(fichier.getAbsolutePath().lastIndexOf("/")+1);
		return (result.substring(0, result.lastIndexOf(".")));
	}
	
	static Couleur findDominantColor(BufferedImage image)
	{
		int y = 0;
		int x = 0;

		int a = 0;
		int r = 0;
		int g = 0;
		int b = 0;
		
		while (x < image.getWidth())
		{
			y = 0;
			while (y < image.getHeight())
			{
				int rgb = image.getRGB(x, y);
				a += (rgb >> 24) & 0xff;
			    r += (rgb >> 16) & 0xff;
			    g += (rgb >> 8) & 0xff;
			    b += rgb & 0xff;
				y++;
			}
			x++;
		}
		
		return (new Couleur(r / (x * y), g / (x * y), b / (x * y), a / (x * y)));
	}

	public ImageModel()
	{
		
	}

	public ImageModel(String path, String name) throws IOException
	{
		File f;
		
	    try
	    {
	    	f = new File(path + "/" + name);
	    	this.image = ImageIO.read(f);
			this.taille = new Dimension(image.getWidth(), image.getHeight());
			this.titre = parseTitre(name);
			this.couleur = findDominantColor(this.image);
			this.note = 1;
			this.temps = System.currentTimeMillis();;
			this.lst_tags = new ArrayList<String>();
	    }
	    catch(IOException e){ System.out.println(e); }
	}

	public String getTitre()
	{
		return (this.titre);
	}

	public void setTitre(String titre)
	{
		this.titre = titre;
	}
	
	public List<String> getTags()
	{
		return (this.lst_tags);
	}

	public void setTags(List<String> lst)
	{
		this.lst_tags = lst;
	}
	
	public void addImageTag(String toAdd)
	{
		this.lst_tags.add(toAdd);
	}
	
	public int getNote()
	{
		return (this.note);
	}
	
	public void setNote(int note)
	{
		this.note = note;
	}
	
	public Couleur getCouleur()
	{
		return (this.couleur);
	}
	
	public void setCouleur(Couleur c)
	{
		this.couleur = c;
	}
	
	public long getTemps()
	{
		return (this.temps);
	}
	
	public void setTemps(long temps)
	{
		this.temps = temps;
	}
}
