
public class Couleur
{
	int red;
	int green;
	int blue;
	int alpha;
	
	public Couleur()
	{
		
	}
	
	public Couleur(int r, int g, int b, int a)
	{
		this.red = r;
		this.green = g;
		this.blue = b;
		this.alpha = a;
	}
	
	public int getBlue()
	{
		return (this.blue);
	}
	
	public void setBlue(int c)
	{
		this.blue = c;
	}

	public int getRed()
	{
		return (this.red);
	}
	
	public void setRed(int c)
	{
		this.red = c;
	}

	public int getGreen()
	{
		return (this.green);
	}
	
	public void setGreen(int c)
	{
		this.green = c;
	}

	public int getAlpha()
	{
		return (this.alpha);
	}
	
	public void setAlpha(int c)
	{
		this.alpha = c;
	}
}
